//
//  simulated_annealing.c
//  TSP
//
//  Created by Stefaan Vermassen on 30/10/13.
//  Copyright (c) 2013 Stefaan Vermassen. All rights reserved.
//

#include <stdio.h>
#include "simulated_annealing.h"
#define START_TEMP 1000
#define SATISFIED 10000

void simulated_annealing_search(best_solution* best, matrix * weights){
    /*int rand_index1, rand_index2, attempt=0;
    double temp = START_TEMP;
    
    while(attempt < SATISFIED)
    {
        rand_index1 = (rand() % (weights->number_of_cities -1))+1;
        rand_index2 = rand_index1+(rand() % (weights->number_of_cities-rand_index1));
    }*/
    
}